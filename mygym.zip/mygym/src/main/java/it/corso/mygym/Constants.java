package it.corso.mygym;

public interface Constants {

     String USER_NOT_FOUND_EXCEPTION = "User with id [%s] was not found.";
}
